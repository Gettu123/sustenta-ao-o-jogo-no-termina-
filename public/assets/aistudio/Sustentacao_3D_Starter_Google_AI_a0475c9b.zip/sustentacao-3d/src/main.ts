import "./style.css";
import { Office3D } from "./scenes/Office3D";

const root = document.querySelector<HTMLElement>("#app");
if (!root) throw new Error("Elemento #app não encontrado.");
new Office3D(root);