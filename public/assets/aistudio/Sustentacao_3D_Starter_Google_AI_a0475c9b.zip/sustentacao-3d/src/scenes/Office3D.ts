import * as THREE from "three";
import { MissionSystem } from "../systems/MissionSystem";

type Interactable = { mesh: THREE.Object3D; name: string; action: () => void };

export class Office3D {
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.1, 200);
  private renderer = new THREE.WebGLRenderer({ antialias: true });
  private player = new THREE.Group();
  private keys = new Set<string>();
  private interactables: Interactable[] = [];
  private mission = new MissionSystem();
  private clock = new THREE.Clock();
  private yaw = 0;
  private pitch = -0.18;
  private xp = 0;
  private energy = 100;
  private stress = 10;
  private reputation = 50;
  private gameClockMinutes = 8 * 60;
  private dialog = document.querySelector<HTMLDivElement>("#dialog")!;
  private dialogTitle = document.querySelector<HTMLHeadingElement>("#dialog-title")!;
  private dialogText = document.querySelector<HTMLParagraphElement>("#dialog-text")!;
  private dialogActions = document.querySelector<HTMLDivElement>("#dialog-actions")!;

  constructor(private root: HTMLElement) {
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.setSize(innerWidth, innerHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    root.prepend(this.renderer.domElement);
    this.scene.background = new THREE.Color("#9bc4df");
    this.scene.fog = new THREE.Fog("#9bc4df", 24, 85);
    this.camera.position.set(0, 5, 8);
    this.createLights();
    this.createOffice();
    this.createPlayer();
    this.bindInput();
    this.resize();
    this.animate();
  }

  private material(color: string, roughness = 0.8) {
    return new THREE.MeshStandardMaterial({ color, roughness });
  }

  private box(name: string, x: number, y: number, z: number, w: number, h: number, d: number, color: string) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), this.material(color));
    mesh.name = name; mesh.position.set(x, y, z); mesh.castShadow = true; mesh.receiveShadow = true;
    this.scene.add(mesh); return mesh;
  }

  private createLights() {
    this.scene.add(new THREE.HemisphereLight(0xd9efff, 0x52606c, 2.0));
    const sun = new THREE.DirectionalLight(0xffffff, 2.3);
    sun.position.set(-8, 14, 8); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
    this.scene.add(sun);
  }

  private createOffice() {
    this.box("floor", 0, -0.15, 0, 32, 0.3, 24, "#aebbc4");
    // Office perimeter and glass-like partitions
    const wallMat = new THREE.MeshStandardMaterial({ color: "#dce7ee", roughness: .35, transparent: true, opacity: .72 });
    const back = new THREE.Mesh(new THREE.BoxGeometry(32, 4, .25), wallMat); back.position.set(0, 2, -12); this.scene.add(back);
    const left = new THREE.Mesh(new THREE.BoxGeometry(.25, 4, 24), wallMat); left.position.set(-16, 2, 0); this.scene.add(left);
    const right = left.clone(); right.position.x = 16; this.scene.add(right);
    // Windows and architectural columns
    for (let x = -12; x <= 12; x += 4) this.box("column", x, 2, -11.6, .22, 4, .3, "#7894a7");
    // Workstations
    for (let row = 0; row < 2; row++) for (let col = 0; col < 4; col++) {
      const x = -10 + col * 6.2, z = -5 + row * 6.2;
      this.box("desk", x, .78, z, 3.1, .18, 1.5, "#654b38");
      this.box("monitor", x, 1.55, z - .35, 1.05, .85, .12, "#172b3c");
      this.box("screen", x, 1.56, z - .275, .88, .65, .02, "#168bd0");
      this.box("keyboard", x, .91, z + .35, .9, .05, .3, "#202d38");
      this.box("chair", x, .55, z + 1.45, .9, .9, .8, "#253e54");
    }
    // Meeting room on the right
    this.box("meeting-table", 11.5, .65, 5, 5, .18, 3, "#75543b");
    for (let i = 0; i < 4; i++) this.box("meeting-chair", 9 + i * 1.6, .5, 7, .75, .9, .75, "#31536d");
    // Coffee corner
    this.box("coffee-counter", -12, .65, 8, 4, 1.3, 1.2, "#57483d");
    this.box("coffee-machine", -12, 1.55, 8, .7, .65, .6, "#202a35");
    // Server / IT zone
    for (let i = 0; i < 3; i++) {
      this.box("server-rack", 12 + i * 1.2, 1.25, -8, .85, 2.5, .8, "#1c2d40");
      this.box("server-led", 12 + i * 1.2, 1.5, -7.56, .12, .08, .03, "#28d8ff");
    }
    // NPC analyst
    const analyst = this.makeNpc("#e1a16d", "#244d72");
    analyst.position.set(-3, 0, -2);
    this.interactables.push({ mesh: analyst, name: "Analista de Folha", action: () => this.openAnalystDialog() });
    const manager = this.makeNpc("#d3a17e", "#243344");
    manager.position.set(11, 0, 2);
    this.interactables.push({ mesh: manager, name: "Gestor da Sustentação", action: () => this.openManagerDialog() });
    // Interactive desk
    const desk = this.box("key-user-desk", 0, .78, 9, 3.5, .18, 1.5, "#634a37");
    this.interactables.push({ mesh: desk, name: "Estação do Key User", action: () => this.openWorkstationDialog() });
    // Ceiling light strips
    for (let x = -10; x <= 10; x += 5) this.box("light-strip", x, 3.85, 0, 2.8, .05, .18, "#f8ffff");
  }

  private makeNpc(shirt: string, pants: string) {
    const npc = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(.32, .7, 4, 8), this.material(shirt));
    body.position.y = .85; body.castShadow = true; npc.add(body);
    const head = new THREE.Mesh(new THREE.SphereGeometry(.25, 16, 12), this.material("#c88d69"));
    head.position.y = 1.55; head.castShadow = true; npc.add(head);
    const legs = new THREE.Mesh(new THREE.BoxGeometry(.48, .55, .3), this.material(pants));
    legs.position.y = .28; npc.add(legs);
    this.scene.add(npc); return npc;
  }

  private createPlayer() {
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(.34, .78, 5, 10), this.material("#145d96"));
    body.position.y = .9; body.castShadow = true; this.player.add(body);
    const head = new THREE.Mesh(new THREE.SphereGeometry(.25, 16, 12), this.material("#a96f4f"));
    head.position.y = 1.65; head.castShadow = true; this.player.add(head);
    const legs = new THREE.Mesh(new THREE.BoxGeometry(.5, .55, .32), this.material("#202a35"));
    legs.position.y = .28; this.player.add(legs);
    this.player.position.set(0, 0, 4);
    this.scene.add(this.player);
  }

  private bindInput() {
    addEventListener("keydown", e => {
      this.keys.add(e.key.toLowerCase());
      if (e.key.toLowerCase() === "e") this.tryInteract();
      if (e.key === "Escape") this.closeDialog();
    });
    addEventListener("keyup", e => this.keys.delete(e.key.toLowerCase()));
    this.renderer.domElement.addEventListener("click", () => this.renderer.domElement.requestPointerLock());
    document.addEventListener("mousemove", e => {
      if (document.pointerLockElement === this.renderer.domElement) {
        this.yaw -= e.movementX * .0025;
        this.pitch = THREE.MathUtils.clamp(this.pitch - e.movementY * .0018, -.55, .15);
      }
    });
    document.querySelector("#close-dialog")?.addEventListener("click", () => this.closeDialog());
    addEventListener("resize", () => this.resize());
  }

  private resize() {
    this.camera.aspect = innerWidth / innerHeight; this.camera.updateProjectionMatrix();
    this.renderer.setSize(innerWidth, innerHeight);
  }

  private movePlayer(dt: number) {
    const forward = new THREE.Vector3(Math.sin(this.yaw), 0, Math.cos(this.yaw));
    const right = new THREE.Vector3(forward.z, 0, -forward.x);
    const dir = new THREE.Vector3();
    if (this.keys.has("w")) dir.add(forward.clone().negate());
    if (this.keys.has("s")) dir.add(forward);
    if (this.keys.has("a")) dir.add(right.clone().negate());
    if (this.keys.has("d")) dir.add(right);
    if (dir.lengthSq() > 0) {
      dir.normalize();
      const speed = this.keys.has("shift") ? 7 : 4.2;
      this.player.position.addScaledVector(dir, speed * dt);
      this.player.rotation.y = Math.atan2(dir.x, dir.z);
      this.energy = Math.max(0, this.energy - dt * (this.keys.has("shift") ? 1.4 : .35));
    }
    this.player.position.x = THREE.MathUtils.clamp(this.player.position.x, -14.5, 14.5);
    this.player.position.z = THREE.MathUtils.clamp(this.player.position.z, -10.5, 10.5);
  }

  private updateCamera() {
    const offset = new THREE.Vector3(Math.sin(this.yaw) * 7, 4.2 + this.pitch * 3, Math.cos(this.yaw) * 7);
    const target = this.player.position.clone().add(new THREE.Vector3(0, 1.2, 0));
    this.camera.position.lerp(target.clone().add(offset), .09);
    this.camera.lookAt(target);
  }

  private tryInteract() {
    let nearest: Interactable | undefined, min = 3.2;
    for (const item of this.interactables) {
      const d = item.mesh.position.distanceTo(this.player.position);
      if (d < min) { min = d; nearest = item; }
    }
    if (nearest) nearest.action();
  }

  private showDialog(title: string, body: string, actions: { label: string; run: () => void }[]) {
    this.dialogTitle.textContent = title; this.dialogText.textContent = body;
    this.dialogActions.replaceChildren();
    actions.forEach(a => {
      const b = document.createElement("button"); b.textContent = a.label;
      b.onclick = a.run; this.dialogActions.appendChild(b);
    });
    this.dialog.classList.remove("hidden");
  }
  private closeDialog() { this.dialog.classList.add("hidden"); }

  private openAnalystDialog() {
    this.showDialog("Analista de Folha", "A rubrica não apareceu no resultado da folha. Ontem funcionava normalmente. Precisamos identificar período, grupo afetado e evidências antes de encaminhar.", [
      { label: "Confirmar impacto", run: () => { this.mission.complete("impact"); this.reputation += 2; this.updateHud(); this.closeDialog(); } },
      { label: "Coletar período, passos e log", run: () => { this.mission.complete("evidence"); this.xp += 20; this.updateHud(); this.closeDialog(); } }
    ]);
  }

  private openManagerDialog() {
    this.showDialog("Gestor da Sustentação", "Temos uma falha na folha e precisamos de diagnóstico, responsável definido e plano de validação. Não avance para produção sem aprovação.", [
      { label: "Entendido — seguir fluxo controlado", run: () => { this.stress = Math.max(0, this.stress - 2); this.updateHud(); this.closeDialog(); } }
    ]);
  }

  private openWorkstationDialog() {
    const missing = this.mission.getFeedback();
    if (this.mission.isApproved()) {
      this.showDialog("Estação do Key User", "Missão aprovada! Todos os critérios obrigatórios foram demonstrados.", [
        { label: "Receber recompensa +100 XP", run: () => { this.xp += 100; this.reputation += 5; this.updateHud(); this.closeDialog(); } }
      ]);
      return;
    }
    this.showDialog("Estação do Key User — Missão 001", "Critérios pendentes: " + missing.join("; ") + ". Esta versão é um protótipo local: a validação é demonstrativa e não acessa um tenant SAP real.", [
      { label: "Encaminhar ao especialista", run: () => { this.mission.complete("route"); this.updateHud(); this.closeDialog(); } },
      { label: "Simular validação em QAS", run: () => { this.mission.complete("qas"); this.updateHud(); this.closeDialog(); } },
      { label: "Documentar solução", run: () => { this.mission.complete("document"); this.updateHud(); this.closeDialog(); } }
    ]);
  }

  private updateHud() {
    const p = this.mission.getProgress();
    document.querySelector("#energy")!.textContent = String(Math.round(this.energy));
    document.querySelector("#stress")!.textContent = String(this.stress);
    document.querySelector("#reputation")!.textContent = String(this.reputation);
    document.querySelector("#xp")!.textContent = String(this.xp);
    document.querySelector("#mission")!.innerHTML = `<strong>MISSÃO 001 — ${p.done}/${p.total}</strong><br/>${this.mission.isApproved() ? "Missão aprovada! Volte à estação para receber XP." : "Critérios concluídos: " + p.done + " de " + p.total + ". Continue investigando."}`;
  }

  private animate = () => {
    requestAnimationFrame(this.animate);
    const dt = Math.min(this.clock.getDelta(), .05);
    this.movePlayer(dt); this.updateCamera();
    this.gameClockMinutes += dt * 1.2;
    const hh = String(Math.floor(this.gameClockMinutes / 60) % 24).padStart(2, "0");
    const mm = String(Math.floor(this.gameClockMinutes % 60)).padStart(2, "0");
    document.querySelector("#clock")!.textContent = `${hh}:${mm}`;
    this.updateHud();
    this.renderer.render(this.scene, this.camera);
  };
}