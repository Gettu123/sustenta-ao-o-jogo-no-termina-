export type Criterion = { id: string; label: string; required: boolean; completed: boolean };
export type Mission = { id: string; title: string; description: string; criteria: Criterion[]; xp: number };

export class MissionSystem {
  mission: Mission = {
    id: "MISSION-001",
    title: "Falha no cálculo da folha",
    description: "Investigue por que uma rubrica não foi calculada no período informado.",
    criteria: [
      { id: "impact", label: "Identificar impacto e população afetada", required: true, completed: false },
      { id: "evidence", label: "Coletar período, passos e log", required: true, completed: false },
      { id: "route", label: "Encaminhar ao especialista correto", required: true, completed: false },
      { id: "qas", label: "Validar a correção em QAS", required: true, completed: false },
      { id: "document", label: "Documentar resultado e próximo passo", required: true, completed: false }
    ],
    xp: 100
  };

  complete(id: string) {
    const criterion = this.mission.criteria.find(c => c.id === id);
    if (criterion) criterion.completed = true;
    return this.isApproved();
  }

  isApproved() {
    return this.mission.criteria.filter(c => c.required).every(c => c.completed);
  }

  getProgress() {
    const done = this.mission.criteria.filter(c => c.completed).length;
    return { done, total: this.mission.criteria.length };
  }

  getFeedback() {
    return this.mission.criteria.filter(c => c.required && !c.completed).map(c => c.label);
  }
}