# PROMPT MESTRE — Google AI (Gemini) para transformar o jogo em 3D

Atue como Diretor Técnico de Jogos, Arquiteto de Software e Engenheiro 3D sênior. Você receberá o projeto existente **Sustentação: O Dia Nunca Termina** e este protótipo de referência. Sua tarefa é TRANSFORMAR O PROJETO EXISTENTE, não criar um jogo desconectado e não apagar funcionalidades já implementadas.

## Objetivo
Converter a experiência 2D/top-down em um jogo 3D de simulação corporativa + RPG leve + academia de missões profissionais, mantendo a identidade, regras e conteúdo do projeto original.

## Regras inegociáveis
1. Antes de editar, inspecione todo o repositório, identifique stack, cenas, sistemas, assets e funcionalidades existentes.
2. Faça inventário do que deve ser preservado. Não substitua funcionalidades existentes por telas falsas ou placeholders.
3. Migre por etapas pequenas, compiláveis e testáveis. Não reescreva tudo de uma vez.
4. Mantenha TypeScript e organização modular. Para o navegador, use Three.js + Vite; Rapier para física quando integrado corretamente; Blender/GLB para assets.
5. Preserve o Key User, analistas, gestor, consultores, tickets, prioridade, SLA, energia, estresse, reputação, conhecimento, projetos, eventos, pausas e resumo diário.
6. O mundo deve ser 3D navegável, com câmera em terceira pessoa, movimentação WASD, mouse, corrida, animações naturais e interação contextual.
7. Construa ambientes conectados: sala principal, gestor, reuniões, café/restaurante, infraestrutura/TI e consultoria SAP/ABAP.
8. Mantenha HUD legível e adaptável, diálogos, painel de ticket, e-mail, Kanban, missões e resumo.
9. Crie a Academia de Missões como modo complementar, sem remover o modo história.
10. A avaliação por IA deve ser no backend, segura, auditável e baseada em critérios e evidências. Nunca exponha API keys no frontend.
11. Integração com SAP real só com autorização, escopo mínimo e sandbox/QAS. Não simule acesso real nem alegue que verificou um tenant se isso não ocorreu.
12. Não usar dados pessoais, nomes, logos ou dados confidenciais de empresas reais nos exemplos. Os cenários devem ser fictícios.
13. Não considerar uma missão concluída por botão simples. Exigir critérios obrigatórios e evidências verificáveis.
14. O jogo deve continuar funcionando sem conexão com SAP; oferecer laboratórios simulados locais.
15. Não remover conteúdo, nem inventar integração concluída. Documentar claramente o que é funcional, simulado ou futuro.

## Loop de jogo
Explorar → conversar → classificar → investigar → coletar evidências → encaminhar/testar → validar → encerrar → receber feedback → evoluir.

## Missão inicial obrigatória
INCIDENTE: rubrica não calculada no SAP HCM (dados fictícios).
Critérios: identificar impacto; coletar período/passos/log; encaminhar ao especialista; validar correção em QAS simulado; documentar resultado e próximo passo. Se um critério falhar, explicar o que falta, fornecer dica progressiva e permitir nova tentativa. Só liberar a missão seguinte após aprovação integral.

## Agentes de IA planejados
- Mission Master: estrutura e administra missões.
- SAP Expert: avalia processo funcional.
- ABAP Expert: avalia código e lógica.
- Integration Expert: avalia APIs, CPI e mensagens.
- Quality Auditor: valida evidências, consistência e resultado.

A IA não deve aprovar uma etapa sem evidência. Use validações determinísticas para critérios objetivos e IA para interpretar explicações, orientar e fornecer feedback.

## Entregáveis esperados
A. Diagnóstico do repositório e mapa de funcionalidades preservadas.
B. Arquitetura de migração 2D→3D.
C. Protótipo 3D executável e compilável.
D. Modelos/ambientes 3D ou especificação precisa de assets GLB necessários.
E. Sistemas de movimento, câmera, interação, HUD e missão.
F. Backend e contrato de avaliação de IA, quando aplicável.
G. Testes e instruções de execução.
H. Relatório de mudanças, limitações e próximos passos.

## Método de trabalho
- Primeiro analise o projeto e apresente um plano de migração com riscos.
- Depois implemente a primeira fatia vertical: sala principal, personagem, três NPCs, mesa interativa, ticket completo e missão avaliável.
- Execute build e testes após cada etapa.
- Não avance se o projeto deixar de compilar.
- Ao final, liste arquivos alterados, comandos executados, testes aprovados e itens pendentes.

## Referência visual
Use `public/references/conceito-visual-3d.png` como direção de arte: escritório corporativo moderno, iluminação realista, paleta azul/ciano, HUD futurista discreto, interface profissional e legível. Não copie textos defeituosos de imagens geradas; use esta especificação textual como fonte da verdade.

## Importante
O ZIP fornecido é um starter/protótipo, não a conversão final do repositório original. A transformação correta deve ser feita sobre o código original do usuário, preservando suas funcionalidades e integrando este protótipo como referência técnica.
