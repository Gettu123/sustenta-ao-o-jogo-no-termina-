# Plano técnico — conversão 3D

## Visão
Preservar o núcleo do projeto original: Key User, analistas, gestor, consultores, tickets, prioridades, SLA, energia, estresse, reputação, projetos, eventos, pausas e resumo do expediente. A mudança principal é a camada de apresentação e interação: de 2D top-down para mundo 3D em terceira pessoa.

## Loop principal
Explorar → conversar → classificar → investigar → coletar evidências → encaminhar/testar → validar → encerrar → receber feedback → evoluir.

## Ambientes
1. Sala principal de Sustentação.
2. Sala do gestor.
3. Sala de reuniões.
4. Área de café/restaurante.
5. Infraestrutura/TI.
6. Consultoria SAP/ABAP.
7. Academia de missões e laboratórios.

## Sistemas
- Movimento e câmera: WASD, mouse, corrida, câmera suave com lerp.
- Interação contextual: tecla E, alcance, foco do objeto, diálogo.
- Tickets: tipo, prioridade P1–P4, impacto, urgência, SLA, status, responsável, histórico e evidências.
- Missões: objetivos, critérios obrigatórios, tentativas, dicas, feedback e recompensa.
- Progressão: XP, competências, níveis e certificados internos.
- Rotina: relógio, energia, estresse, pausas e eventos.
- Segurança: ambientes fictícios por padrão; integração externa somente autorizada, segregada e auditável.

## IA avaliadora
A avaliação deve receber:
- definição versionada da missão;
- critérios e pesos;
- evidências estruturadas;
- resultados observáveis do laboratório;
- política de tentativas e dicas.

A IA deve retornar JSON validável contendo `criterionId`, `status`, `evidence`, `feedback` e `nextHint`. O servidor valida o JSON e aplica regras determinísticas. A IA não deve declarar sucesso com base apenas em texto livre do jogador.

## Integrações SAP
Fase posterior. Usar APIs, conectores ou agente de laboratório com autorização explícita, escopo mínimo, ambiente sandbox/QAS e logs. Nunca guardar credenciais no frontend. Não permitir alterações em PRD sem fluxo de aprovação externo e auditável.

## Arquitetura proposta
- Frontend: TypeScript, Vite, Three.js.
- Física: Rapier 3D.
- Assets: Blender, GLB/glTF.
- Backend: Node.js + API.
- Dados: PostgreSQL.
- Avaliação: serviço de IA no backend + validador determinístico.
- Persistência: contas, saves, tentativas, competências e auditoria.

## Fases e aceite
1. Mundo 3D: mapa, personagem, câmera, colisões, interações.
2. Simulação: tickets, diálogos, chefe, consultores, café e rotina.
3. Academia: missões, laboratórios e progressão.
4. IA: avaliação por critério, tutor e histórico.
5. Integrações: laboratório SAP autorizado.
6. Expansão: multiplayer, projetos de equipe, ranking e novos cenários.

## Regra de qualidade
Uma missão só é aprovada quando todos os critérios obrigatórios têm evidência suficiente e validação determinística ou confirmação de fonte confiável. A IA pode orientar, mas não deve inventar evidências.
