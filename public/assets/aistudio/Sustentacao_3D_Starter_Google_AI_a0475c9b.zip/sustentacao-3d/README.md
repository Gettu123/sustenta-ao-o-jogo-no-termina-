# Sustentação: O Dia Nunca Termina — protótipo 3D

Protótipo inicial de conversão do jogo de simulação corporativa 2D para 3D no navegador.

## Rodar localmente
1. Instale Node.js LTS.
2. Extraia o ZIP.
3. No terminal, dentro desta pasta:
   ```bash
   npm install
   npm run dev
   ```
4. Abra o endereço local exibido pelo Vite.

## Controles
- WASD: movimentar
- Mouse: câmera (clique no cenário para capturar o mouse)
- E: interagir com personagem/estação próxima
- Shift: correr
- Esc: fechar diálogo

## O que já existe neste protótipo
- Cena 3D navegável com Three.js.
- Escritório com mesas, monitores, sala de reunião, café e racks de TI.
- Personagem controlável e NPCs demonstrativos.
- Câmera em terceira pessoa.
- HUD de expediente, energia, estresse, reputação e XP.
- Missão inicial com critérios de validação e progressão demonstrativa.

## Limitações explícitas
- A avaliação é local e simulada; não se conecta a SAP.
- NPCs são modelos provisórios construídos por geometria básica.
- Ainda faltam modelos GLB, animações profissionais, colisão física completa, backend, autenticação, banco de dados e integração de IA.
- Rapier está incluído como dependência planejada, mas ainda não conectado ao ciclo de física.
- Não use dados, credenciais ou ambientes produtivos reais.

## Próximas entregas
Consulte `docs/PLANO_TECNICO.md` e `docs/PROMPT_GOOGLE_AI.md`.
